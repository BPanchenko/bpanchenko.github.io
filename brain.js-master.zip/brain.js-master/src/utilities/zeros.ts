/**
 * Returns an array of zeros
 */
export function zeros(size: number): Float32Array {
  return new Float32Array(size);
}
