export function randomWeight(): number {
  return Math.random() * 0.4 - 0.2;
}
