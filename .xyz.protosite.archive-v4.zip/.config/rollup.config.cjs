module.exports = {
	input: '.core/main.js',
	output: {
		sourcemap: false,
		format: 'esm',
		file: 'assets/core.js'
	},
	plugins: [
		require("@rollup/plugin-node-resolve").nodeResolve(),
		require("rollup-plugin-terser").terser()
	]
}
