import selector from 'posthtml-match-helper'

import configBeautifyHTML from './posthtml-beautify.config.js'
import configPostCSS from './postcss.config.cjs'

import pluginBeautifyHTML from 'posthtml-beautify'
import pluginExtendHTML from 'posthtml-extend'
import pluginHtmlnano from 'htmlnano'
import pluginPostCSS from 'posthtml-postcss'
import { noopener } from 'posthtml-noopener'

const isProd = ((env = '') => env.trim() === 'production')(process.env.NODE_ENV)
const root = process.cwd()

const plugins = [
	pluginExtendHTML({
		root: './.templates',
		expressions: {
			locals: {
				currentYear: '2024',
				repository: 'https://github.com/BPanchenko/protosite-uikit'
			},
			strictMode: false
		},
		tagName: 'template',
		slotTagName: 'slot',
		fillTagName: 'block'
	}),
	// pluginHtmlnano({ removeComments: 'all' }),
	pluginPostCSS(configPostCSS.plugins, {}, /^text\/css$/),
	noopener()
]

if (isProd) {
	plugins.push(
		cleanup,
		updatePaths
	)
}

plugins.push(
	pluginBeautifyHTML(configBeautifyHTML)
)

function updatePaths(tree) {
	tree.match(
		[
			selector("[data-url^='/assets/']"),
			selector("[href^='/assets/']"),
			selector("[src^='/assets/']")
		],
		node => {
			if (typeof node.attrs.src === 'string') {
				node.attrs.src = node.attrs.src.replace('/assets/', '/')
			}
			if (typeof node.attrs.href === 'string') {
				node.attrs.href = node.attrs.href.replace('/assets/', '/')
			}
			if (typeof node.attrs['data-url'] === 'string') {
				node.attrs['data-url'] = node.attrs['data-url'].replace('/assets/', '/')
			}
			return node
		}
	)
	return tree
}

function cleanup(tree) {
	tree.match([{
		attrs: { 'data-env': 'dev' }
	}], node => ({ tag: false }))
	return tree
}

export default {
	root,
	input: [
		'components/*.html',
		'elements/*.html',
		'errors/*.html',
		'objects/*.html',
		'styles/*.html',
		'blank.html',
		'index.html',
		'underconstruction.html'
	],
	output: 'assets',
	plugins
}