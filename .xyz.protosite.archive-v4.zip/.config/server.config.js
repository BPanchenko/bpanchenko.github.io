import posthtmlConfig from "./posthtml.config.js"

export default {
	applyCSSLive: true,
	domain: 'local.protosite.rocks',
	index: 'index.html',
	exts: [ 'html', 'css', 'js', 'mjs', 'ico', 'png', 'svg' ],
	root: '.',
	ports: {
		client: 8080,
		livereload: 35729
	},
	watch: [
		...posthtmlConfig.input,
		'.templates/*.html',
		'assets/core.js',
		'assets/design.css'
	]
}
