import html from "@html-eslint/eslint-plugin";
import htmlParser from "@html-eslint/parser";

export default [
	{
		ignores: ["assets/yandex_433676a0cc82c286.html"]
	},
	{
		...html.configs["flat/recommended"],
		files: ["**/*.html"],
		plugins: {
			"@html-eslint": html,
		},
		languageOptions: {
			parser: htmlParser,
		},
		rules: {
			...html.configs["flat/recommended"].rules, // Must be defined. If not, all recommended rules will be lost
			"@html-eslint/indent": ["error", "tab"],
			"@html-eslint/require-img-alt": 1,
			"@html-eslint/require-img-alt": 1,
			"@html-eslint/no-multiple-h1": 0,
			"@html-eslint/element-newline": ["error", { "skip": ["code", "link", "pre", "span", "template"] }]
		},
	},
];