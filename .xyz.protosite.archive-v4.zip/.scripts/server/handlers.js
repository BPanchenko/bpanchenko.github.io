import * as ports from "port-authority"

import childProcess from "child_process"
import coloring from "chalk"
import config from "../../.config/server.config.js"
import livereload from "livereload"
import path from "path"

const BASE_URL = `http://${config.domain}:${config.ports.client}`

const livePortFound = (port) => {
	const liveServer = livereload.createServer({ ...config, port })

	// Start watching
	if (Array.isArray(config.watch)) {
		liveServer.watch(config.watch.map(item => path.resolve(process.cwd(), item)))
	} else {
		liveServer.watch(path.resolve(process.cwd(), config.watch))
	}
	
	// Out message
	console.log(coloring.green('LiveReload enabled on port ' + port))

	// Run Chrome Browser
	childProcess.exec(`start chrome ${BASE_URL}`)
}

export const serverReady = () => {
	console.log(coloring.green(`DEV Server started at ${BASE_URL}`))
	ports.find(config.ports.livereload).then(livePortFound)
}
