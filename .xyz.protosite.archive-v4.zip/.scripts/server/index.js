import express from "express"
import nocache from "nocache"

import config from "../../.config/server.config.js"
import { htmlSourcesRouter } from "./routing.js"
import { serverReady } from "./handlers.js"

const server = express()

server.use(nocache())
server.use(htmlSourcesRouter)
server.use(express.static(config.root))
server.listen(config.ports.client, serverReady)
