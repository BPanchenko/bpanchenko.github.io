const nodeIsCode = node => (node.tagName.toLowerCase() === 'code')

function selectNode(node) {
	if (document.body.createTextRange) {
		const range = document.body.createTextRange()
		range.moveToElementText(node)
		range.select()
	} else if (window.getSelection) {
		const selection = window.getSelection()
		const range = document.createRange()
		range.selectNodeContents(node)
		selection.removeAllRanges()
		selection.addRange(range)
	} else {
		console.warn("Could not select text in node: Unsupported browser.")
	}
}

window.addEventListener('DOMContentLoaded', _ => {
	document.body.addEventListener(
		'click',
		({ target }) => nodeIsCode(target) && selectNode(target),
		false
	)
})
