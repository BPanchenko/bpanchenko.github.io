const snippetSrc = 'http://'
	+ (location.host || 'localhost').split(':')[0]
	+ ':35729/livereload.js?snipver=1'

const script = document.createElement('script')
script.src = snippetSrc

document.head.appendChild(script)
